# ethereal RDG experimental branch (deprecated)

Archived 2026-10-14 before the `framegraph` branches (local and origin) were deleted
from the aggregate repo and from ethereal-donut, ethereal-nvrhi and ethereal-samples.

Each repo has three files:
- <repo>.patch  : net change, `git diff --binary --full-index <base> framegraph`.
                  Apply with `git apply --index <repo>.patch` on a checkout of <base>.
                  Verified: applying it reproduces the framegraph tree exactly.
- <repo>.log    : commit list (git log --graph) of <base>..framegraph.
- <repo>.bundle : the full commits, `git bundle` of <base>..framegraph.
                  Restore with `git fetch <repo>.bundle framegraph:framegraph` in a repo that has <base>.

A per-commit patch series (git format-patch) is deliberately not used: the branch history
contains merges with ethereal-dev/main, and the series does not apply linearly.

| repo             | base (merge-base) | framegraph head |
|------------------|-------------------|-----------------|
| ethereal         | 0100410           | 6130bc1         |
| ethereal-donut   | 9f51e7a           | 34ea046         |
| ethereal-nvrhi   | 8d6fa3d           | 13b60ff         |
| ethereal-samples | 54f0325           | d2eee6f         |

The aggregate's base 0100410 pins exactly the submodule bases above, so the aggregate
patch (gitlink bumps + docs/plans) pairs with the three submodule patches.
